# Password MUST be provided in the ./pwd.txt file
## with no more characters before or after that

## to run with **tmux**, run the command ***./runWithTmux.sh*** and as first argument,
## give the **command to run with** tmux and as second, give the tmux **session-name**
```
./runWithTmux.sh './install-prereqs.sh' 'install-prereqs
```